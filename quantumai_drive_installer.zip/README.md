QuantumAI Drive Package

- Local-only AI orchestration
- Admin-approved workflows
- Drive-bound execution
- Expandable agents and plugins

Run:
chmod +x install.sh
./install.sh
