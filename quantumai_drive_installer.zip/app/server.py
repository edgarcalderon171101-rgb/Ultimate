import json, os, time
from app.orchestrator import Orchestrator

ROOT = os.path.dirname(os.path.dirname(__file__))
CONF = os.path.join(ROOT, "runtime", "config.json")

with open(CONF) as f:
    cfg = json.load(f)

orch = Orchestrator(cfg)
orch.start()
