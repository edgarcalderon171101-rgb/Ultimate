class BaseAgent:
    def tick(self): pass

class ResearchAgent(BaseAgent):
    def tick(self):
        print("[ResearchAgent] idle")

class CodeAgent(BaseAgent):
    def tick(self):
        print("[CodeAgent] idle")
