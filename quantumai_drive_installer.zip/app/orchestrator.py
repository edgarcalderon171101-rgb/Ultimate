import time
from app.agents import ResearchAgent, CodeAgent

class Orchestrator:
    def __init__(self, cfg):
        self.cfg = cfg
        self.agents = [
            ResearchAgent(),
            CodeAgent(),
        ]
    def start(self):
        print("QuantumAI running (admin-controlled, local-only)")
        while True:
            for a in self.agents:
                a.tick()
            time.sleep(self.cfg.get("loop_interval", 5))
