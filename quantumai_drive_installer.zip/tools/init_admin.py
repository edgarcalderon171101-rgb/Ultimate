import json, os, getpass, hashlib, uuid
ROOT = os.path.dirname(os.path.dirname(__file__))
CONF = os.path.join(ROOT, "runtime", "config.json")
admin = getpass.getuser()
key = hashlib.sha256((admin+str(uuid.uuid4())).encode()).hexdigest()
cfg = {
    "admin": admin,
    "admin_key": key,
    "loop_interval": 5,
    "network": "local-only"
}
with open(CONF, "w") as f:
    json.dump(cfg, f, indent=2)
print("Admin initialized. Save your key securely.")
print(key)
