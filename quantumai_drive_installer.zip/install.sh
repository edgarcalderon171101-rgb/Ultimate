#!/usr/bin/env bash
set -e
echo "QuantumAI Drive Installer"
ROOT="$(cd "$(dirname "$0")" && pwd)"
CONF="$ROOT/runtime/config.json"
mkdir -p "$ROOT/runtime/logs" "$ROOT/runtime/models" "$ROOT/runtime/plugins"
if [ ! -f "$CONF" ]; then
  python3 "$ROOT/tools/init_admin.py"
fi
python3 "$ROOT/app/server.py"
