# QuantumAI Repository

This repo contains the Linux installer, AI orchestrator skeleton, plugin structure, and configuration templates.
